<div class="modal-content modal-content-<?php echo $modalsize ?>">
  <?php echo $form ?>
</div>